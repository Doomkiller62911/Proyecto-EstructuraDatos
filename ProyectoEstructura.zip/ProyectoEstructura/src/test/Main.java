
package test;

import Controllers.MenuController;
import Controllers.MetodosController;

public class Main {
    MetodosController metodos = new MetodosController();
    static MenuController menu = new MenuController();
    public static void main(String[] args) {
        menu.MenuPrincipal();
        
        
        
    }
    
}
